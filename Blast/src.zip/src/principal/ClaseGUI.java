package principal;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class ClaseGUI extends JPanel implements ActionListener{
	//Constructores
	JComboBox <String> cadena;
	protected JTextField porcentaje;
	protected static String proteinsString ; 
	protected static String nucelotidString;
	JRadioButton proteinsButton; 
	JRadioButton nucleotidButton;
	ButtonGroup group;
	JPanel paraRadioButtons;
	JButton enviar;
	
	public ClaseGUI() {
		
		
	//Create the radio buttons
	String proteinsString = new String("proteins");
	String nucelotidString = new String("nucleotid");
	proteinsButton = new JRadioButton(proteinsString, true);
	nucleotidButton = new JRadioButton(nucelotidString, false);
	
	//Group the radio buttons.
	group = new ButtonGroup();
	group.add(proteinsButton);
	group.add(nucleotidButton);
	
	//creo un panel donde a�ado mis opciones usando add
	paraRadioButtons= new JPanel();
	paraRadioButtons.add(proteinsButton);
	paraRadioButtons.add(nucleotidButton);
	add(paraRadioButtons);
	
	//add combobox secuencia
	cadena= new JComboBox<String>();
	cadena.setEditable(true);
	cadena.addItem(" ");

	
	
	
	//add  porcentaje
	porcentaje= new JTextField("porcentaje entre 0 y 1", 10);
	
	
	
	/*porcentaje= new JComboBox<Double>();
	porcentaje.setEditable(true);
	for(double i= 0.0; i<1.0; i=(i+0.01)) {
		porcentaje.addItem(i);
	}*/
	
	enviar = new JButton("Enviar");
	enviar.addActionListener(this);
	cadena.addActionListener(this);
	porcentaje.addActionListener(this);
	
	
	
	add(cadena);
	add(porcentaje);
	add(enviar);
	
	
	
	
}
	
	
	//genero un action Listener para cuando el cliente a�ade una nueva cadena me la ense�e
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==enviar) {
			porcentaje.getAction();
			if(!(cadena.getSelectedItem()== cadena.addItem((String) cadena.getSelectedItem())));{�
			cadena.addItem((String)cadena.getSelectedItem());}
			
		
			
			System.out.println("La cadena a procesar sera la siguiente" +  cadena.getSelectedItem() + paraRadioButtons.getAccessibleContext());
		
			
		}


	}
}
